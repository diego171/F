# Reporte de Unidad — Proyecto Android

Proyecto Android Studio listo para compilar. La aplicación contiene el formulario HTML original dentro de un WebView y funciona sin internet.

## Requisitos
- Android Studio reciente
- JDK incluido/recomendado por Android Studio
- SDK Android 35

## Abrir
1. Descomprime el ZIP.
2. Abre la carpeta `ReporteUnidadAndroid` en Android Studio.
3. Espera a que Gradle sincronice.
4. Ejecuta en un teléfono/emulador o usa Build > Build APK(s).

La APK de debug normalmente quedará en:
`app/build/outputs/apk/debug/app-debug.apk`

## Datos de la app
- Nombre: Reporte de Unidad
- Package: com.reporteunidad.app
- Versión: 1.0
- Min Android: 6.0 (API 23)
- Funciona offline.
- El botón de copiar usa el portapapeles nativo de Android.
