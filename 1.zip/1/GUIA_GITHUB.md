# Cómo compilar la APK automáticamente con GitHub Actions

## 1. Crear el repositorio
En GitHub crea un repositorio nuevo, por ejemplo:
`ReporteUnidad`

Puede ser público o privado.

## 2. Subir el proyecto
Descomprime `ReporteUnidadAndroid.zip` y sube TODO el contenido de la carpeta al repositorio.

Es importante conservar:
`.github/workflows/build-apk.yml`

## 3. Ejecutar la compilación
En GitHub entra al repositorio y selecciona:

Actions → Compilar APK → Run workflow

También se compilará automáticamente cuando hagas push a `main` o `master`.

## 4. Descargar la APK
Cuando termine el proceso:

Actions → Compilar APK → selecciona la ejecución terminada

En la parte inferior, en **Artifacts**, aparecerá:

`Reporte-de-Unidad-APK`

Descarga ese archivo ZIP, descomprímelo y encontrarás:

`app-debug.apk`

Esa es la APK que puedes instalar en Android.

## Nota
Esta configuración genera una APK DEBUG, adecuada para instalar y probar en teléfonos Android.
